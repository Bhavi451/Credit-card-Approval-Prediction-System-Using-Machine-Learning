from flask import Flask, render_template, request
import pandas as pd
import joblib

app = Flask(__name__)

# Load model and feature list
model = joblib.load("model/model.pkl")
feature_columns = joblib.load("model/features.pkl")


@app.route("/")
def home():
    return render_template("index.html")


@app.route("/predict", methods=["POST"])
def predict():
    try:
        data = {
            "CODE_GENDER": request.form["CODE_GENDER"],
            "FLAG_OWN_CAR": request.form["FLAG_OWN_CAR"],
            "FLAG_OWN_REALTY": request.form["FLAG_OWN_REALTY"],
            "CNT_CHILDREN": int(request.form["CNT_CHILDREN"]),
            "AMT_INCOME_TOTAL": float(request.form["AMT_INCOME_TOTAL"]),
            "NAME_INCOME_TYPE": request.form["NAME_INCOME_TYPE"],
            "NAME_EDUCATION_TYPE": request.form["NAME_EDUCATION_TYPE"],
            "NAME_FAMILY_STATUS": request.form["NAME_FAMILY_STATUS"],
            "NAME_HOUSING_TYPE": request.form["NAME_HOUSING_TYPE"],
            "AGE": int(request.form["AGE"]),
            "YEARS_EMPLOYED": int(request.form["YEARS_EMPLOYED"]),
            "FLAG_MOBIL": "Yes",
            "FLAG_WORK_PHONE": request.form["FLAG_WORK_PHONE"],
            "FLAG_PHONE": request.form["FLAG_PHONE"],
            "FLAG_EMAIL": request.form["FLAG_EMAIL"],
            "OCCUPATION_TYPE": request.form["OCCUPATION_TYPE"],
            "CNT_FAM_MEMBERS": float(request.form["CNT_FAM_MEMBERS"]),
            "MONTHS_BALANCE": int(request.form["MONTHS_BALANCE"])
        }

        # Convert to DataFrame
        input_df = pd.DataFrame([data])

        # One-hot encode
        input_df = pd.get_dummies(input_df)

        # Match training columns
        input_df = input_df.reindex(columns=feature_columns, fill_value=0)

        prediction = model.predict(input_df)

        if prediction[0] == 1:
            result = "❌ Credit Card Rejected"
        else:
            result = "✅ Credit Card Approved"

        return render_template("result.html", prediction=result)

    except Exception as e:
        return f"Error: {e}"


if __name__ == "__main__":
    app.run(debug=True)